# whatsapp-live-cricket-bot
This is a whatsapp bot that uses Cricket API to fetch different types of match data including lives ones, past and upcoming ones and send them on your whatsapp number.
Too easy to use. Simply put your credentials from Twilio and Cric into the place, install twilio api and you will be ready to go.
